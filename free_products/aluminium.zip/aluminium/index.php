<?php get_header(); ?>

<?php
	if ( have_posts() ) :
	while ( have_posts() ) : the_post();
	
	
	if ( is_singular() ) :
		the_title( '<h1 class="entry-title">', '</h1>' );
	else :
		the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
	endif;

	if ( 'post' === get_post_type() ) :	
		echo "Posted On: " . get_the_date() . " On " . get_the_time();
	endif;	

	the_content();

	endwhile;
	endif;

?>






<?php get_footer();