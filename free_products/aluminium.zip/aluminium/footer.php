
<footer>
<div class="footer">
<div class="container">
	<div class="col-md-3">
	<div class="social">
		<ul>
		<li><a href="<?php echo get_theme_mod('linkedin') ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
		<li><a href="<?php echo get_theme_mod('youtube') ?>"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
		<li><a href="<?php echo get_theme_mod('twitter') ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
		<li><a href="<?php echo get_theme_mod('facebook') ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
		</ul>
	</div>
	</div>
	<div class="col-md-2"></div>
	<div class="col-md-7 footer_texts">
		<?php echo get_theme_mod('footer_text') ?>
	</div>
</div>
</div>	
</footer>

<?php wp_footer(); ?>

</body>
</html>