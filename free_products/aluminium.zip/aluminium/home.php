<?php /* Template Name: Home Page */ ?>

<?php get_header(); ?>

<!-- Index Page Banner -->
<div class="prime_banner" style="background-image: url('<?php echo get_theme_mod('homepage_banner_upload') ?>');">
<div class="container">
<div class="row">
<div class="col-md-12">
	<h1><?php echo get_theme_mod('homepage_banner_h1') ?></h1>
	<p><?php echo get_theme_mod('homepage_banner_p') ?></p>
</div>
</div>
</div>
</div>
<!-- Index Page Banner -->

<!-- Features -->
<div class="features">
<div class="container">
	<div class="row">
	<div class="col-md-12">
		<h2>Convenient, Low-Cost, Do-it-Yourself Physio</h2>		
	</div>
	</div>

	<div class="row">
		<div class="col-md-4">
			<div class="features_boxes">
			<div><img src="<?php echo get_theme_mod('features_boxes1_img') ?>" class="img-responsive" /></div>
			<h2>Low Cost</h2>
			<h3>Half the Price of a Standard Physio Visit</h3>
			</div>
		</div>
		<div class="col-md-4">
			<div class="features_boxes">
			<div><img src="<?php echo get_theme_mod('features_boxes2_img') ?>" class="img-responsive" /></div>
			<h2>Convenient</h2>
			<h3>No need to leave the house, Zero downtime from work, Start Today</h3>
			</div>
		</div>
		<div class="col-md-4">
			<div class="features_boxes">
			<div><img src="<?php echo get_theme_mod('features_boxes3_img') ?>" class="img-responsive" /></div>
			<h2>More Effective</h2>
			<h3>You can treat yourself daily and get rapid results, rather than waiting for appointments a week apart</h3>
			</div>
		</div>	
	</div>
</div>
</div>
<!-- Features -->

<!-- Steps -->
<div class="steps_section">
<div class="container">
	<div class="row">
	<div class="col-md-12">
	<h2>3 STEP PROCESS</h2>
	</div>
	</div>

	<div class="row">
		<div class="col-md-4">
		<div class="steps">
			<h2>1</h2>
			<h3>Complete an Online Form</h3>
		</div>
		</div>
		<div class="col-md-4">
		<div class="steps">
			<h2>2</h2>
			<h3>Receive a Working Diagnosis</h3>
		</div>
		</div>
		<div class="col-md-4">
		<div class="steps">
			<h2>3</h2>
			<h3>Receive Your Custom Treatment Video</h3>
		</div>
		</div>
	</div>
</div>
</div>
<!-- Steps -->

<!-- Pricing Table -->
<div class="pricing_table_section">
	<div class="container">

		<div class="row">
		<div class="col-md-12" style="text-align: center;">
		<?php echo get_theme_mod('pricing_title_subtitle') ?>
		</div>
		</div>

		<div class="row">
			<div class="col-md-4">
			<div class="pricing_table">
				<div class="pricing_table_header">
				<?php echo get_theme_mod('package1_header') ?>
				</div>
				<?php echo get_theme_mod('package1_text') ?>
				<div class="pricing_table_button"><a href="<?php echo get_theme_mod('package1_price_link') ?>" target="_blank">$97</a></div>
			</div>
			</div>

			<div class="col-md-4">
			<div class="pricing_table">
				<div class="pricing_table_header">
				<?php echo get_theme_mod('package2_header') ?>
				</div>
				<?php echo get_theme_mod('package2_text') ?>
				<div class="pricing_table_button"><a href="<?php echo get_theme_mod('package2_price_link') ?>" target="_blank">$165</a></div>
			</div>
			</div>

			<div class="col-md-4">
			<div class="pricing_table">
				<div class="pricing_table_header">
				<?php echo get_theme_mod('package3_header') ?>
				</div>
				<?php echo get_theme_mod('package3_text') ?>
				<div class="pricing_table_button"><a href="<?php echo get_theme_mod('package3_price_link') ?>" target="_blank">$297</a></div>
			</div>
			</div>
		</div>
		
	</div>
</div>
<!-- Pricing Table -->

<!-- What Are They Saying Section -->
<div class="testimonials">
<div class="container">
	<div class="row">
	<div class="col-md-12">
	<h2><?php echo get_theme_mod('testimonials_title') ?></h2>
	</div>
	</div>

	<div class="row">
	<div class="col-md-6 testimonial_videos"><?php echo get_theme_mod('testimonial1') ?></div>
	<div class="col-md-6 testimonial_videos"><?php echo get_theme_mod('testimonial2') ?></div>
	</div>	
</div>
</div>
<!-- What Are They Saying Section -->

<!-- FAQ -->
<div class="faq">
<div class="container">
	<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<h2>Frequently Asked Questions</h2>
	</div>
	</div>

	<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<h3 class="ques">Q. What is Black Hair Shampoo?</h3>
	<span class="ans">Black hair shampoo is a kind of special shampoo which can dye your hair into black in 5 minutes, (totally blackening the grey and white hair), just like using normal
shampoo at bathroom or shower. It is time-saving, convenient and economical. With a high-tech and mild formula, our shampoo will not harm hair and hurt the scalp at all. It would not cause allergy.</span>
	<div class="divider"></div>
	</div>
	</div>

	<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<h3 class="ques">Q. How long do I have to leave it on my hair before I rinse it off?</h3>
	<span class="ans">Just 5 minutes. You will see how fast is changes color and how nice and shinny the end result is.</span>
	<div class="divider"></div>
	</div>
	</div>

	<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<h3 class="ques">Q. How often should I use it and for how long?</h3>
	<span class="ans">Every 4 or 5 weeks and you can use it forever. It will only make your hair look better every time. Guaranteed!</span>
	<div class="divider"></div>
	</div>
	</div>

	<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<h3 class="ques">Q. How much money can I save if I use Black Hair Shampoo?</h3>
	<span class="ans">It’s up to 10 times cheaper that dying your hair at the Hair Salon and its %100 healthier and healthy.</span>
	<div class="divider"></div>
	</div>
	</div>

	<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<h3 class="ques">Q. How do they make it possible to have such a good result so fast, especially if &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; it’s a natural product?</h3>
	<span class="ans">The Natural Herb Black Hair Shampoo is a formula of natural luxurious French herbal medicines, includes various Chinese herb and medicine essence and herbal nourishing cream such as Noni, wild ginseng, wild ganoderma lucidum and so on, Combined with various fruit gathering essence, amino acid, ZPT, collagen, etc. The magic black hair magic shampoo took the hair nutrition and health experts for FIVE years to develop it.</span>
	<div class="divider"></div>
	</div>
	</div>

	<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<h3 class="ques">Q. My hair is all yellow and dry from the Sun. Can Black Hair Shampoo fix it?</h3>
	<span class="ans">As the Natural Herb Black Hair Shampoo is a kind of nutrition shampoo. It will absolutely make it look like it was never on the sun and it will be shinny, gorgeous and healthy. Just how you deserve it!</span>	
	</div>
	</div>	
</div>
</div>
<!-- FAQ -->

<!-- CTA -->
<div class="cta">
<div class="container">
<div class="row">
	<div class="col-md-6">
		<?php echo get_theme_mod('row3_texts') ?>
	</div>
	<div class="col-md-3"></div>
	<div class="col-md-3">
		<div class="button2"><a href="<?php echo get_theme_mod('button2_link') ?>"><?php echo get_theme_mod('button2_text') ?></a></div>
	</div>
</div>
</div>
</div>
<!-- CTA -->

<!-- About Section -->
<div class="about">
<div class="container">
	<div class="row">
	<div class="col-md-12" style="text-align: center;">
	<?php echo get_theme_mod('about_title_subtitle') ?>
	</div>
	</div>

	<div class="row">
		<div class="col-md-4"><img src="/wp-content/themes/aluminium/images/physio_body_points.jpg" class="img-responsive"></div>
		<div class="col-md-8">
			<h3>We Are Seeing Great Success With These Common Conditions</h3>
			<ul>
				<li>Neck Pain</li>
				<li>Back Pain</li>
				<li>Shoulder Pain</li>
				<li>Knee Pain</li>
				<li>Ankle/Foot Pain</li>
				<li>Sports Injuries</li>
				<li>Overuse Injuries</li>
				<li>Whiplash</li>
			</ul>
		</div>
	</div>
</div>
</div>
<!-- About Section -->

<?php get_footer();
