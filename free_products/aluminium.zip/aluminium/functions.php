<?php
if ( ! function_exists( 'aluminium_setup' ) ) :

function aluminium_setup() {
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );

	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'aluminium' ),
	) );
}
endif;
add_action( 'after_setup_theme', 'aluminium_setup' );

function theme_customize_cleanup( $wp_customize ) { 
	$wp_customize->remove_section("title_tagline");
	$wp_customize->remove_section("static_front_page");
	$wp_customize->remove_section("custom_css");
}
add_action( "customize_register", "theme_customize_cleanup" );

/* Removing WP Emoji */
function disable_wp_emojicons() { 
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' ); 
	add_filter( 'tiny_mce_plugins', 'disable_emojicons_tinymce' );
}
add_action( 'init', 'disable_wp_emojicons' );
 
function disable_emojicons_tinymce( $plugins ) {
	if ( is_array( $plugins ) ) {
		return array_diff( $plugins, array( 'wpemoji' ) );
	} else {
		return array();
	}
}
/* Removing WP Emoji */

remove_action('wp_head', 'wp_generator'); //removes meta name generator.
remove_action('wp_head', 'wp_shortlink_wp_head'); //removes shortlink.
remove_action('wp_head', 'rsd_link'); //removes EditURI/RSD (Really Simple Discovery) link.
remove_action('wp_head', 'wlwmanifest_link'); //removes wlwmanifest (Windows Live Writer) link.
remove_action( 'wp_head', 'wp_resource_hints', 2 ); //removes dns-prefetch link.
remove_action( 'wp_head', 'rest_output_link_wp_head'); //removes json api link.
add_filter( 'feed_links_show_comments_feed', '__return_false' ); //disable comments feed

function aluminium_scripts() {
	wp_enqueue_style( 'aluminium-style', get_stylesheet_uri() );
	wp_enqueue_style( 'normalize', get_template_directory_uri() . '/css/normalize_5.0.0.css' );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.css' );
	wp_enqueue_style( 'custom', get_template_directory_uri() . '/css/custom.css' );
	wp_enqueue_style( 'open-sans', 'https://fonts.googleapis.com/css?family=Open+Sans:400,600,700' );
	wp_enqueue_script( 'fontawesome', 'https://use.fontawesome.com/9f3a441fb2.js', array(), null, true );
}
add_action( 'wp_enqueue_scripts', 'aluminium_scripts' );

/* Header */
function header_settings_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'header',
		array (
		            'title' => 'Header Settings',
		            'description' => '',
		            'priority' => 35,
		)
	);

	$wp_customize->add_setting( 'logo_upload' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'logo-upload',
			array (
				'label' => 'Upload Logo',
				'section' => 'header',
				'settings' => 'logo_upload'
			)
		)
	);

	$wp_customize->add_setting( 'button1_text' );
    	$wp_customize->add_control(
    		'button1_text',
		array (
			'label' => 'Button 1 Text',
			'section' => 'header',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'button1_link' );
    	$wp_customize->add_control(
    		'button1_link',
		array (
			'label' => 'Button 1 Link',
			'section' => 'header',
			'type' => 'text',
		)
	);
}
add_action( 'customize_register', 'header_settings_customizer' );
/* Header */

/* Home Page Banner Section */
function homepage_banner_settings_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'homepage_banner',
		array (
		            'title' => 'Custom Home Page Banner Settings',
		            'description' => '',
		            'priority' => 36,
		)
	);

	$wp_customize->add_setting( 'homepage_banner_upload' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'banner_upload',
			array (
				'label' => 'Upload Home Page Banner',
				'section' => 'homepage_banner',
				'settings' => 'homepage_banner_upload'
			)
		)
	);

	$wp_customize->add_setting( 'homepage_banner_h1' );
    	$wp_customize->add_control(
    		'homepage_banner_h1',
		array (
			'label' => 'Home Page Banner Title',
			'section' => 'homepage_banner',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'homepage_banner_p' );
    	$wp_customize->add_control(
    		'homepage_banner_p',
		array (
			'label' => 'Home Page Banner  Sub Title',
			'section' => 'homepage_banner',
			'type' => 'text',
		)
	);
}
add_action( 'customize_register', 'homepage_banner_settings_customizer' );
/* Home Page Banner Section */

/* Features */
function row2_settings_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'features',
		array (
		            'title' => 'Features',
		            'description' => '',
		            'priority' => 37,
		)
	);

    	$wp_customize->add_setting( 'features_title' );
    	$wp_customize->add_control(
    		'features_title',
		array (
			'label' => 'Features Section Title',
			'section' => 'row2',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'features_boxes1_img' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'features_boxes1_img',
			array (
				'label' => 'Features Boxes Image 1',
				'section' => 'features',
				'settings' => 'features_boxes1_img'
			)
		)
	);

    	$wp_customize->add_setting( 'features_boxes2_img' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'features_boxes2_img',
			array (
				'label' => 'Features Boxes Image 2',
				'section' => 'features',
				'settings' => 'features_boxes2_img'
			)
		)
	);

	$wp_customize->add_setting( 'features_boxes3_img' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'features_boxes3_img',
			array (
				'label' => 'Features Boxes Image 3',
				'section' => 'features',
				'settings' => 'features_boxes3_img'
			)
		)
	);
}
add_action( 'customize_register', 'row2_settings_customizer' );
/* Features */

/* Pricing */
function online_consultation_page_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'online_consultation_page',
		array (
		            'title' => 'Pricing Table',
		            'description' => '',
		            'priority' => 40,
		)
	);

	$wp_customize->add_setting( 'pricing_title_subtitle' );
    	$wp_customize->add_control(
    		'pricing_title_subtitle',
		array (
			'label' => 'Pricing Title and SubTitle',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package1_header' );
    	$wp_customize->add_control(
    		'package1_header',
		array (
			'label' => 'Package1 Header',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package1_text' );
    	$wp_customize->add_control(
    		'package1_text',
		array (
			'label' => 'Package1 Text',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package1_price_link' );
    	$wp_customize->add_control(
    		'package1_price_link',
		array (
			'label' => 'Package1 Price Link',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package2_header' );
    	$wp_customize->add_control(
    		'package2_header',
		array (
			'label' => 'Package2 Header',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package2_text' );
    	$wp_customize->add_control(
    		'package2_text',
		array (
			'label' => 'Package2 Text',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package2_price_link' );
    	$wp_customize->add_control(
    		'package2_price_link',
		array (
			'label' => 'Package2 Price Link',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package3_header' );
    	$wp_customize->add_control(
    		'package3_header',
		array (
			'label' => 'Package3 Header',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package3_text' );
    	$wp_customize->add_control(
    		'package3_text',
		array (
			'label' => 'Package3 Text',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package3_price_link' );
    	$wp_customize->add_control(
    		'package3_price_link',
		array (
			'label' => 'Package3 Price Link',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

}
add_action( 'customize_register', 'online_consultation_page_customizer' );
/* Pricing */

/* Testimonials Section */
function testimonials_section_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'testimonials_section',
		array (
		            'title' => 'Testimonials Section',
		            'description' => '',
		            'priority' => 37,
		)
	);

	$wp_customize->add_setting( 'testimonials_title' );
    	$wp_customize->add_control(
    		'testimonials_title',
		array (
			'label' => 'Testimonials Title',
			'section' => 'testimonials_section',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'testimonial1' );
    	$wp_customize->add_control(
    		'testimonial1',
		array (
			'label' => 'Testimonial 1',
			'section' => 'testimonials_section',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'testimonial2' );
    	$wp_customize->add_control(
    		'testimonial2',
		array (
			'label' => 'Testimonial 2',
			'section' => 'testimonials_section',
			'type' => 'text',
		)
	);
}
add_action( 'customize_register', 'testimonials_section_customizer' );
/* Testimonials Section */