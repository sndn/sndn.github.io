<?php
if ( ! function_exists( 'aluminium_setup' ) ) :

function aluminium_setup() {
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );

	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'aluminium' ),
	) );
}
endif;
add_action( 'after_setup_theme', 'aluminium_setup' );

function aluminium_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'aluminium' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'aluminium' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'aluminium_widgets_init' );
add_theme_support( 'customize-selective-refresh-widgets' ); // Add theme support for selective refresh for widgets.

function theme_customize_cleanup( $wp_customize ) { 
	$wp_customize->remove_section("title_tagline");
	$wp_customize->remove_section("static_front_page");
	$wp_customize->remove_section("custom_css");
}
add_action( "customize_register", "theme_customize_cleanup" );

/* Removing WP Emoji */
function disable_wp_emojicons() { 
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' ); 
	add_filter( 'tiny_mce_plugins', 'disable_emojicons_tinymce' );
}
add_action( 'init', 'disable_wp_emojicons' );
 
function disable_emojicons_tinymce( $plugins ) {
	if ( is_array( $plugins ) ) {
		return array_diff( $plugins, array( 'wpemoji' ) );
	} else {
		return array();
	}
}
/* Removing WP Emoji */

remove_action('wp_head', 'wp_generator'); //removes meta name generator.
remove_action('wp_head', 'wp_shortlink_wp_head'); //removes shortlink.
remove_action('wp_head', 'rsd_link'); //removes EditURI/RSD (Really Simple Discovery) link.
remove_action('wp_head', 'wlwmanifest_link'); //removes wlwmanifest (Windows Live Writer) link.
remove_action( 'wp_head', 'wp_resource_hints', 2 ); //removes dns-prefetch link.
remove_action( 'wp_head', 'rest_output_link_wp_head'); //removes json api link.
add_filter( 'feed_links_show_comments_feed', '__return_false' ); //disable comments feed

function aluminium_scripts() {
	wp_enqueue_style( 'aluminium-style', get_stylesheet_uri() );
	wp_enqueue_style( 'normalize', get_template_directory_uri() . '/css/normalize_5.0.0.css' );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.css' );
	wp_enqueue_style( 'custom', get_template_directory_uri() . '/css/custom.css' );
	wp_enqueue_style( 'open-sans', 'https://fonts.googleapis.com/css?family=Open+Sans:400,600,700' );
	wp_enqueue_script( 'fontawesome', 'https://use.fontawesome.com/9f3a441fb2.js', array(), null, true );
}
add_action( 'wp_enqueue_scripts', 'aluminium_scripts' );

/* Cleaning Wp Nav */
//Deletes all CSS classes and id's, except for those listed in the array below
function custom_wp_nav_menu($var) {
  return is_array($var) ? array_intersect($var, array(
        //List of allowed menu classes
        'current_page_item',
        'current_page_parent',
        'current_page_ancestor',
        'first',
        'last',
        'vertical',
        'horizontal'
        )
    ) : '';
}
add_filter('nav_menu_css_class', 'custom_wp_nav_menu');
add_filter('nav_menu_item_id', 'custom_wp_nav_menu');
add_filter('page_css_class', 'custom_wp_nav_menu');
//Replaces "current-menu-item" with "active"
function current_to_active($text){
    $replace = array(
        //List of menu item classes that should be changed to "active"
        'current_page_item' => 'active',
        'current_page_parent' => 'active',
        'current_page_ancestor' => 'active',
    );
    $text = str_replace(array_keys($replace), $replace, $text);
        return $text;
    }
add_filter ('wp_nav_menu','current_to_active');
//Deletes empty classes and removes the sub menu class
function strip_empty_classes($menu) {
    $menu = preg_replace('/ class=""| class="sub-menu"/','',$menu);
    return $menu;
}
add_filter ('wp_nav_menu','strip_empty_classes');
/* Cleaning Wp Nav */

/* Header */
function header_settings_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'header',
		array (
		            'title' => 'Header Settings',
		            'description' => '',
		            'priority' => 35,
		)
	);

	$wp_customize->add_setting( 'logo_upload' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'logo-upload',
			array (
				'label' => 'Upload Logo',
				'section' => 'header',
				'settings' => 'logo_upload'
			)
		)
	);

	$wp_customize->add_setting( 'button1_text' );
    	$wp_customize->add_control(
    		'button1_text',
		array (
			'label' => 'Button 1 Text',
			'section' => 'header',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'button1_link' );
    	$wp_customize->add_control(
    		'button1_link',
		array (
			'label' => 'Button 1 Link',
			'section' => 'header',
			'type' => 'text',
		)
	);
}
add_action( 'customize_register', 'header_settings_customizer' );
/* Header */

/* Home Page Banner Section */
function homepage_banner_settings_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'homepage_banner',
		array (
		            'title' => 'Custom Home Page Banner Settings',
		            'description' => '',
		            'priority' => 36,
		)
	);

	$wp_customize->add_setting( 'homepage_banner_upload' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'banner_upload',
			array (
				'label' => 'Upload Home Page Banner',
				'section' => 'homepage_banner',
				'settings' => 'homepage_banner_upload'
			)
		)
	);

	$wp_customize->add_setting( 'homepage_banner_h1' );
    	$wp_customize->add_control(
    		'homepage_banner_h1',
		array (
			'label' => 'Home Page Banner Title',
			'section' => 'homepage_banner',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'homepage_banner_p' );
    	$wp_customize->add_control(
    		'homepage_banner_p',
		array (
			'label' => 'Home Page Banner  Sub Title',
			'section' => 'homepage_banner',
			'type' => 'text',
		)
	);
}
add_action( 'customize_register', 'homepage_banner_settings_customizer' );
/* Home Page Banner Section */

/* Features */
function row2_settings_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'features',
		array (
		            'title' => 'Features',
		            'description' => '',
		            'priority' => 37,
		)
	);

    	$wp_customize->add_setting( 'features_title' );
    	$wp_customize->add_control(
    		'features_title',
		array (
			'label' => 'Features Section Title',
			'section' => 'row2',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'features_boxes1_img' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'features_boxes1_img',
			array (
				'label' => 'Features Boxes Image 1',
				'section' => 'features',
				'settings' => 'features_boxes1_img'
			)
		)
	);

    	$wp_customize->add_setting( 'features_boxes2_img' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'features_boxes2_img',
			array (
				'label' => 'Features Boxes Image 2',
				'section' => 'features',
				'settings' => 'features_boxes2_img'
			)
		)
	);

	$wp_customize->add_setting( 'features_boxes3_img' );
	$wp_customize->add_control (
		new WP_Customize_Image_Control (
			$wp_customize,
			'features_boxes3_img',
			array (
				'label' => 'Features Boxes Image 3',
				'section' => 'features',
				'settings' => 'features_boxes3_img'
			)
		)
	);
}
add_action( 'customize_register', 'row2_settings_customizer' );
/* Features */

/* Pricing */
function online_consultation_page_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'online_consultation_page',
		array (
		            'title' => 'Pricing Table',
		            'description' => '',
		            'priority' => 40,
		)
	);

	$wp_customize->add_setting( 'pricing_title_subtitle' );
    	$wp_customize->add_control(
    		'pricing_title_subtitle',
		array (
			'label' => 'Pricing Title and SubTitle',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package1_header' );
    	$wp_customize->add_control(
    		'package1_header',
		array (
			'label' => 'Package1 Header',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package1_text' );
    	$wp_customize->add_control(
    		'package1_text',
		array (
			'label' => 'Package1 Text',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package1_price_link' );
    	$wp_customize->add_control(
    		'package1_price_link',
		array (
			'label' => 'Package1 Price Link',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package2_header' );
    	$wp_customize->add_control(
    		'package2_header',
		array (
			'label' => 'Package2 Header',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package2_text' );
    	$wp_customize->add_control(
    		'package2_text',
		array (
			'label' => 'Package2 Text',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package2_price_link' );
    	$wp_customize->add_control(
    		'package2_price_link',
		array (
			'label' => 'Package2 Price Link',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package3_header' );
    	$wp_customize->add_control(
    		'package3_header',
		array (
			'label' => 'Package3 Header',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package3_text' );
    	$wp_customize->add_control(
    		'package3_text',
		array (
			'label' => 'Package3 Text',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

    	$wp_customize->add_setting( 'package3_price_link' );
    	$wp_customize->add_control(
    		'package3_price_link',
		array (
			'label' => 'Package3 Price Link',
			'section' => 'online_consultation_page',
			'type' => 'textarea',
		)
	);

}
add_action( 'customize_register', 'online_consultation_page_customizer' );
/* Pricing */

/* Testimonials Section */
function testimonials_section_customizer ( $wp_customize ) {
	$wp_customize->add_section (
		'testimonials_section',
		array (
		            'title' => 'Testimonials Section',
		            'description' => '',
		            'priority' => 37,
		)
	);

	$wp_customize->add_setting( 'testimonials_title' );
    	$wp_customize->add_control(
    		'testimonials_title',
		array (
			'label' => 'Testimonials Title',
			'section' => 'testimonials_section',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'testimonial1' );
    	$wp_customize->add_control(
    		'testimonial1',
		array (
			'label' => 'Testimonial 1',
			'section' => 'testimonials_section',
			'type' => 'text',
		)
	);

    	$wp_customize->add_setting( 'testimonial2' );
    	$wp_customize->add_control(
    		'testimonial2',
		array (
			'label' => 'Testimonial 2',
			'section' => 'testimonials_section',
			'type' => 'text',
		)
	);
}
add_action( 'customize_register', 'testimonials_section_customizer' );
/* Testimonials Section */

/* Pagination */
function wpbeginner_numeric_posts_nav() {

if( is_singular() )
return;

global $wp_query;

/** Stop execution if there's only 1 page */
if( $wp_query->max_num_pages <= 1 )
return;

$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
$max   = intval( $wp_query->max_num_pages );

/** Add current page to the array */
if ( $paged >= 1 )
$links[] = $paged;

/** Add the pages around the current page to the array */
if ( $paged >= 3 ) {
$links[] = $paged - 1;
$links[] = $paged - 2;
}

if ( ( $paged + 2 ) <= $max ) {
$links[] = $paged + 2;
$links[] = $paged + 1;
}

echo '<div class="navigation"><ul>' . "\n";

/** Previous Post Link */
if ( get_previous_posts_link() )
printf( '<li>%s</li>' . "\n", get_previous_posts_link() );

/** Link to first page, plus ellipses if necessary */
if ( ! in_array( 1, $links ) ) {
$class = 1 == $paged ? ' class="active"' : '';

printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );

if ( ! in_array( 2, $links ) )
echo '<li>…</li>';
}

/** Link to current page, plus 2 pages in either direction if necessary */
sort( $links );
foreach ( (array) $links as $link ) {
$class = $paged == $link ? ' class="active"' : '';
printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
}

/** Link to last page, plus ellipses if necessary */
if ( ! in_array( $max, $links ) ) {
if ( ! in_array( $max - 1, $links ) )
echo '<li>…</li>' . "\n";

$class = $paged == $max ? ' class="active"' : '';
printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
}

/** Next Post Link */
if ( get_next_posts_link() )
printf( '<li>%s</li>' . "\n", get_next_posts_link() );

echo '</ul></div>' . "\n";

}
/* Pagination */