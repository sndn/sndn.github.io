<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>

<body>

<header>
	<div class="topbar">
		<div class="container">
			<div class="col-md-5">
				<img src="<?php echo get_theme_mod('logo_upload') ?>" class="img-responsive">
			</div>
			<div class="col-md-4">
			</div>
			<div class="col-md-3">
				<div class="button1"><a href="<?php echo get_theme_mod('button1_link') ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo get_theme_mod('button1_text') ?></a></div>
			</div>
		</div>
	</div>
</header>